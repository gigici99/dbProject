package progettoDB;

public class Main {

	public static void main(String[] args) {
		FinestraQuery x = new FinestraQuery();
		Interface i=new Interface();
	}

}
